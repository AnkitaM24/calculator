# 📌 React Assignment: Calculator Builder

This project is a drag-and-drop calculator builder built using React, Zustand, and Tailwind CSS. It allows users to create a customizable calculator by dynamically adding, removing, and arranging buttons and operations.

## 🎯 Features

- ✅ Drag & Drop Components – Users can add/remove buttons dynamically.
- ✅ Predefined Components – Includes number buttons (0-9), operations (+, -, *, /).
- ✅ Custom Layout – Users can arrange buttons as they like.
- ✅ Calculation Logic – The calculator functions correctly based on user input.
- ✅ State Management with Zustand – Manages dynamic components efficiently.
- ✅ Tailwind CSS Styling – Clean and responsive UI.

Check out the live demo [here](https://calculator-builder-sigma.vercel.app).

## ✨ Bonus Features

- ⭐ Dark Mode Toggle
- ⭐ Persistence with Local Storage (Saves Calculator Layout)

## 🛠️ Tech Stack

- **React** – UI development
- **Zustand** – State management
- **Tailwind CSS** – Styling
- **@dnd-kit** – Drag and drop functionality

## ⚙️ Installation

If you'd like to fork this repository and customize it, follow these steps:

1. Clone the repository: `git clone https://github.com/amanpandey3956/Calculator-Builder.git`.

2. Install the dependencies: `npm install or yarn install`.

3. Start the development server: `npm run dev`.

Your application should now be running on [http://localhost:5173](http://localhost:5173).

## 📬 Connect with Me

- My [Links for Socials](https://linktr.ee/Aman.Pandey).